import requests
import sys

S = requests.Session()

f= open("wikivn.txt","w+")

firstPage = "Bàn"
URL = "https://vi.wikipedia.org/w/api.php"
listPage = []

#Get pageid of wikipedia page base on it's title - use API
def paramsSource(title):
    return {
        "action":"query",
        "format":"json",
        "titles":title
    }

#Get links of wikipedia page base on it's title - use API
def params(title):
    return {
        "action":"query",
        "format":"json",
        "prop": "links",
        "pllimit":"max",
        "titles":title
    }

#Get links of page wikipedia with title and push pageid to file with graph form
def backlinks(title):
    #Get links
    R = S.get(url=URL, params=params(title))
    DATA = R.json()

    #Get pageid
    R1 = S.get(url=URL, params=paramsSource(title))
    DATA1 = R1.json()
    #Count number of line - node
    num_lines = sum(1 for line in open('wikivn.txt'))
    #if number of node > 1000 then stop program
    if(num_lines > 1000):
        sys.exit()
    
    for item in DATA1['query']['pages']:
        firstPageID = item
    for item in DATA['query']['pages'][firstPageID]["links"]:
        R2 = S.get(url=URL, params=params(item['title']))
        DATA2 = R2.json()
        for id in DATA2['query']['pages']:
            pageID = id
        if(pageID != "-1"):
            listPage.append(item['title'])
            f.write("%s\t%s\n" % (firstPageID, pageID))
    return listPage

#Initital with first page
listPage = backlinks(firstPage)
print(listPage)

#Continue with links of first Page
newListPage = []
for page in listPage:
    newListPage = backlinks(page)
    print(newListPage)
f.close()