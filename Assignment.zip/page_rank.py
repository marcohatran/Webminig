import snap
import requests

S = requests.Session()

f= open("20182_IT4868_Assignment01_GroupXXX_ranking.txt.txt","w+")
URL = "https://vi.wikipedia.org/w/api.php"

def params(pageid):
    return {
        "action":"query",
        "format":"json",
        "prop": "info",
        "pageids":pageid
    }

#Import graph from file
G0 = snap.LoadEdgeList(snap.PNGraph, "wikivn.txt", 0, 1)
PRankH = snap.TIntFltH()
#Calculate for graph G0
snap.GetPageRank(G0, PRankH)
#Sort Pagerank
PRankH.SortByDat(False)

f.write("Bàn    1651")
f.write("PageRank   Title")

for item in PRankH:
    print item, PRankH[item]
    R = S.get(url=URL, params=params(item))
    DATA = R.json()
    for id in DATA['query']['pages']:
        pageID = id
    title = DATA['query']['pages'][pageID]["title"]
    print(title)
    f.write("%0.4f\t%s\n" % (PRankH[item], title.encode('utf-8')))