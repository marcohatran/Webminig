Bắt đầu từ 1 trang bất kỳ trreen wiki tiếng việt, mở rộng ra các trang wiki  khác thống qua hyperlink
Thực hiện pagerank trên đồ thị và liệt kê theo thứ tự giảm dần của ranking
Gợi ý dùng SNAP(snap.stanford.edu)
Nộp bài qua email hieunk@soict.hust.edu.vn
	20182_IT4868_Assignment01_GroupXXX
trong đó XXX là STT của nhóm trên file đăng kí
20182_IT4868_Assignment01_GroupXXX_ranking.txt
	-Dòng 1: title của trang bắt đầu, n- số lượng đỉnh trong đồ thị(cách nhau bơi tab)
	-Dòng 2: Pagerak, Title các nhau bởi dấu tab
	-n dòng tiếp: mỗi dòng chứa pagerank và title của mỗi trang wiki, cách nhau bởi dấu tab và được sắp xếp theo thứ tự của pagerank. Giá trị pagerank chỉ lấy 4 số thập phân.
20182_IT4868_Assignment01_GroupXXX_report.pdf
	-Trình bày vì sao lại chọn độ lớn đồ thị là n đỉnh 
	-Nhận xét, giải thích kết quả(vd dựa trên 100 top ranking)

-----------------------------------------------------------------------

https://vi.wikipedia.org/w/api.php?action=query&titles=Ai
https://vi.wikipedia.org/w/api.php?action=query&prop=info&pageids=2287042&inprop=url



